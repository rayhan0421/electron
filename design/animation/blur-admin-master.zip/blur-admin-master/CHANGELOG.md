v1.2.0 - 16 May 2016
--------------------
- Refactoring to improve customization, fixes #22, #26
- Add documentation
- Sidebar refactoring, fixes #14, #15, #27
- Bootstrap select refactoring #18

v1.1.1 - 11 Apr 2016
--------------------
- Improved scrolling performance, fixes #2
- Set 0.9.5 version for the Chartist library by default, fixes #5
