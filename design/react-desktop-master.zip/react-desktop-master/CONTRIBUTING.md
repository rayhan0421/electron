# Contributing Guidelines

We are open to, and grateful for, any contributions made by the community.

## Reporting Issues and Asking Questions

Before opening an issue, please search the [issue tracker](https://github.com/gabrielbull/react-desktop/issues) 
to make sure your issue hasn’t already been reported.

