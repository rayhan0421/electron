# Installation

To install the stable version:

> npm install react-desktop --save

This assumes you are using [npm](https://www.npmjs.com/) as your package manager.
