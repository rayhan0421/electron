import React, { Component } from 'react';
import { Label } from 'react-desktop/windows';

export default class extends Component {
  render() {
    return (
      <Label>My Label</Label>
    );
  }
}
