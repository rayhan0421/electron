import React, { Component } from 'react';
import { Label } from 'react-desktop/macOs';

export default class extends Component {
  render() {
    return (
      <Label>My Label</Label>
    );
  }
}
