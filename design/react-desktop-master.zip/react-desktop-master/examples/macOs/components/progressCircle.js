import React, { Component } from 'react';
import { ProgressCircle } from 'react-desktop/macOs';

export default class extends Component {
  render() {
    return (
      <ProgressCircle size={25}/>
    );
  }
}
