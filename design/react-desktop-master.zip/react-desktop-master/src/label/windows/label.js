import Label from '../../text/windows/text';

export default Label;
