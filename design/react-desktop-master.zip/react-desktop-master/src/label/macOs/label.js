import Label from '../../text/macOs/text';

export default Label;
