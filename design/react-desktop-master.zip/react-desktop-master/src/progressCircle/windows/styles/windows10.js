export default {
  progress: {
    width: '20px',
    height: '20px',
    position: 'relative'
  },

  container: {
    position: 'relative',
    height: '20px'
  },

  absolute: {
    position: 'absolute',
    top: 0,
    left: 0
  }
};
