export default {
  header: {
    top: '0px',
    left: '0px',
    width: '100%',
    borderBottomWidth: '1px',
    borderBottomStyle: 'solid',
    borderBottomColor: '#c9c9c9',
    boxSizing: 'border-box'
  }
};
