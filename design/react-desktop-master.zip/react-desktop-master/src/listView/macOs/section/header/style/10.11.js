export default {
  title: {
    margin: '9px 0px',
    padding: '0px 10px',
    fontWeight: 'normal'
  }
};
