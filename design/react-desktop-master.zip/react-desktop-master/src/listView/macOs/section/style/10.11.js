export default {
  list: {
    listStyle: 'none',
    padding: '0px',
    margin: '0px'
  }
};
