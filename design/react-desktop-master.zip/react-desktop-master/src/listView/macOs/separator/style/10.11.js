export default {
  separator: {
    height: '1px',
    margin: '0px',
    padding: '0px',
    border: 'none'
  }
};
