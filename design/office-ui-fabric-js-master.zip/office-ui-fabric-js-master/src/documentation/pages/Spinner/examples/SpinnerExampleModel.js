var SpinnerExampleModel = {
}

module.exports = SpinnerExampleModel;
