var OverlayModels = {
  "default": {
  },
  "dark": {
    "modifier": "dark"
  }
}

module.exports = OverlayModels;