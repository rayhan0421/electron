var ButtonExamplePrimaryModel = {
  "label": "Create Account",
  "modifier": "primary",
  "tag": "button"
}

module.exports = ButtonExamplePrimaryModel;