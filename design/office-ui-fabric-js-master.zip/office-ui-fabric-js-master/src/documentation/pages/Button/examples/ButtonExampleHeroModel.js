var ButtonExampleHeroModel =  {
  "label": "Create Account",
  "icon": "Add",
  "modifier": "hero",
  "tag": "button"
}

module.exports = ButtonExampleHeroModel;