var TextFieldExampleModel = {
  "label": "Name",
  "textfield": true
}

module.exports = TextFieldExampleModel;
