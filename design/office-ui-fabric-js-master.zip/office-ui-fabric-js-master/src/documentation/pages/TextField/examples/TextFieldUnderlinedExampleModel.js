var TextFieldUnderlinedExampleModel = {
  "label": "Name",
  "textfield": true,
  "modifier": "underlined"
}

module.exports = TextFieldUnderlinedExampleModel;
