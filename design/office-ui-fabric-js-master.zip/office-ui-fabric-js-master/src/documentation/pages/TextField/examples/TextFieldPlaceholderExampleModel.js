var TextFieldPlaceholderExampleModel = {
  "label": "Given name",
  "textfield": true,
  "modifier": "placeholder"
}

module.exports = TextFieldPlaceholderExampleModel;
