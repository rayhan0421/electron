var PersonaCardExampleProps = {
  "default": {
    "title": "Example.jpg",
    "description": "My Progress Description"
  }
}

module.exports = PersonaCardExampleProps;
