var TableExampleModel = {
  "headers": [
    {
      "value": "Location"
    },
    {
      "value": "Modified"
    },
    {
      "value": "Type"
    },
    {
      "value": "File Name"
    }
  ],
  "rows": [
    {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    },
      {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    },
      {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    },
      {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    },
      {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    },
      {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    },
      {
      "columns": [
        {
          "value": "Location"
        },
        {
          "value": "Modified"
        },
        {
          "value": "Type"
        },
        {
          "value": "File Name"
        }
      ]
    }
  ]
}

module.exports = TableExampleModel;
