var LabelExampleModel = {
  "props": {
    "label": "Name"
  },
  "propsRequired": {
    "label": "Name",
    "state": "is-required"
  },
  "propsDisabled": {
    "label": "Name",
    "state": "is-disabled"
  }
}

module.exports = LabelExampleModel;